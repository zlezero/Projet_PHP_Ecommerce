    <footer class="py-2 bg-dark fixed-bottom">
        <div class="container text-center text-white">
            <a class="px-2 fa-lg li-ic center"><i class="fab fa-linkedin-in" style="font-size: 14px;"> </i></a>
            <!-- Facebook -->
            <a class="px-2 fa-lg fb-ic center"><i class="fab fa-facebook-f" style="font-size: 14px;"> </i></a>
            <!-- Email -->
            <a class="px-2 fa-lg email-ic center"><i class="fas fa-envelope" style="font-size: 14px;"> </i></a>
            <p class="m-0">Copyright &copy; VintAIR 2020</p>
        </div>
    </footer>

    </body>

</html>